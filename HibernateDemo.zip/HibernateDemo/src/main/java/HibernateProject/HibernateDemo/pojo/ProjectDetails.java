package HibernateProject.HibernateDemo.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TblProjectDetails")
public class ProjectDetails {
	@Id
	private int projectId;
	@Column(length = 25)
	private String projectDesc;
	private int duration;
	public ProjectDetails(int projectId, String projectDesc, int duration) {
		super();
		this.projectId = projectId;
		this.projectDesc = projectDesc;
		this.duration = duration;
	}
	public int getProjectId() {
		return projectId;
	}
	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}
	public String getProjectDesc() {
		return projectDesc;
	}
	public void setProjectDesc(String projectDesc) {
		this.projectDesc = projectDesc;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
}
