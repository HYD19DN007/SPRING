package HibernateProject.HibernateDemo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import HibernateProject.HibernateDemo.pojo.ProjectDetails;

public class Demo1 {
public static void main(String[] args) {
	Configuration cfg=new Configuration();
	cfg.configure("HibernateProject/HibernateDemo/hibernate.cfg.xml");
	SessionFactory factory =cfg.buildSessionFactory();
	Session session=factory.openSession();
	ProjectDetails P=new ProjectDetails(100, "HMS", 20);
	Transaction T=session.beginTransaction();
	session.save(P);
	T.commit();
	session.close();
	factory.close();
	
	
}
	
}
