package com.example.techwave.demorestClient.model.pojo;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

public class Book {
	private int bookId;
	private String bookName;
	private String publisher;
	private String type;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate dop;
	private int price;

	public Book() {
	}

	public Book(int bookId, String bookName, String publisher, String type, LocalDate dop, int price) {
		super();
		this.bookId = bookId;
		this.bookName = bookName;
		this.publisher = publisher;
		this.type = type;
		this.dop = dop;
		this.price = price;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public LocalDate getDop() {
		return dop;
	}

	public void setDop(LocalDate dop) {
		this.dop = dop;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
}