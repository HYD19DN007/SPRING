package com.example.techwave.demorestClient.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.techwave.demorestClient.model.dao.BookServiceImpl;

@Controller
public class BookController {
	@Autowired
	BookServiceImpl bookServiceImpl;
	
	@RequestMapping("/get")
	public String getAllBooks(Model M)
	{
		System.out.println(bookServiceImpl.GetBooks().size());
		M.addAttribute("blist",bookServiceImpl.GetBooks());
		return "DisplayBooks";
	}
	}
