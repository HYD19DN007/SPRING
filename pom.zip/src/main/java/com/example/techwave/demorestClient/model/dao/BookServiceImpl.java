package com.example.techwave.demorestClient.model.dao;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.client.RestTemplate;

import com.example.techwave.demorestClient.model.pojo.Book;

public class BookServiceImpl {
@Autowired	
RestTemplate restTemplate;
public String url="http://localhost:9990/";

public List<Book> GetBooks()
{
	Book books[]= restTemplate.getForObject(url+"getall", Book[].class);
	return Arrays.asList(books);
	
}
public Book GetBookById(int id)
{
	Map<String, Integer> params=new HashMap<String,Integer>();
	params.put("bookId", id);
	Book books= restTemplate.getForObject(url+"getbyId", Book.class,params);
	return books;
	
}
public String InsertBook(Book B)
{
	String Str= restTemplate.postForObject(url+"insert",B, String.class);
	return Str;
	
}


}
