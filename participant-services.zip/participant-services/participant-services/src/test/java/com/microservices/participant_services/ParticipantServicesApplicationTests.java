package com.microservices.participant_services;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParticipantServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
