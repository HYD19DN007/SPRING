function Validate()
{
var eno=document.getElementsByName("empno")[0].value;
var en=document.getElementsByName("ename")[0].value;
var p=document.getElementById("pwd").value;
var g=true;
alert(document.getElementById("transport").value);
var Str='';	
if(eno.trim().length==0)
	{
	Str="Please enter Employee No";	
	}

if(en.trim().length==0)
	{
	Str=Str+"\nPlease enter Employee name";
	}
if(!validatepwd(p))
	{
	Str=Str+"\nPassword must contain 1 Capital letter , 1 Numeric , 1 special charecter alteast ";
	}
for(i=0;i<3;i++)
	{
		if(document.getElementsByName("gender")[i].checked)
		{
			g=false;
		}
	}
	if(g)
	{
		Str=Str+"\n Select the gender";	
	}	



if(Str!='')
{
	alert(Str);
	return false;
}
else
	return true;
}


function validatepwd(p)
{
var flag=true;
var num=0;
var cap=0;
var sch=0;
if(p.trim().length<8)
{
	flag=false;
}
var pattern = new RegExp('[A-Z]');
var patternnum = new RegExp('[0-9]');
var patternsp=new RegExp('[A-Za-z 0-9]');

	for(i=0;i<p.trim().length;i++)
	{
		
		if(pattern.test(p[i]))
		{
		cap++;
		}
		else if(patternnum.test(p[i]))
		{
		num++;
		}
		else{
		if(!patternsp.test(p[i]))
		{
		sch++;
		}	
	}
	}
if(cap==0)
{
		flag=false;
}
if(num==0)
{
		flag=false;
}
if(sch==0)
	{
		flag=false;
	}


return flag;
}



