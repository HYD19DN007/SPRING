import React from "react";
// function Greet()
// {
// return (<h1>Hello Techwave</h1>);

// }
const PropsExt=({name,lname})=>{
return( <h1>Hello {name}  {lname}


</h1>)

}
export default PropsExt;