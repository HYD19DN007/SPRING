import React, { Component } from 'react'
import ChildComponent from './ChildComponent'


class ParentComponent extends Component {

constructor(props) {
  super(props)

  this.state = {
     parentName:'Parent'
  }
this.greetParent=this.greetParent.bind(this)
}
ChangeState=()=>{
this.setState({
parentName:'I Child'
},()=>{alert(`Hello One  ${this.state.parentName}`)})

}



greetParent()
{
    alert('grretParent1')
    alert(`Hello ${this.state.parentName}`)
    this.ChangeState()
    alert('grretParent2')
    alert('grretParent3')
}
    render() {

    return (
      <div>
        <div>{this.state.parentName}</div>
        <ChildComponent greethandler={this.greetParent}></ChildComponent>
      </div>
    )
  }
}

export default ParentComponent