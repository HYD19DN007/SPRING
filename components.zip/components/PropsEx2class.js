import React ,{Component} from 'react'
class PropsEx2class extends Component
{
render()
{
return (
<h1>Welcom {this.props.name} {this.props.lname}</h1>

)


}

} 

export default PropsEx2class