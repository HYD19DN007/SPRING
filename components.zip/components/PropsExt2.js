import React from "react";

const PropsExt2=props=>{
const{name,lname}=props
return (
<div>
<h1>
    {name}  {lname}
</h1>
</div>)

}
export default PropsExt2;