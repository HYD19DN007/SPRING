import React, { Component } from 'react'

class LifeCylceB extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         name:'Gayatri'

      }
    console.log('LifeCycle B Constructor')
    }
    static getDerivedStateFromProps(props,state)
    {
        console.log('LifeCycle B static method')
        return null
    }
    componentDidMount()
    {
        console.log('LifeCycle B did mount method')
        return null
        
    }
  render() {
        console.log('LifeCycle B render')
        return (
      
      <div>LifeCylceB</div>
    )
  }
}

export default LifeCylceB