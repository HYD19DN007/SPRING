import React from 'react'
function NameList() {
const names=['Tom','Jerry','Kate']
const namelist=names.map(n=><h2>{n}</h2>)
//   return (
//     <div>
//         {
//         names.map(n=><h2>{n}</h2>)
//         }
//         </div>
        
//         )
return <h1>{namelist}</h1>
}

export default NameList