import React from 'react'

function PersonList() {
const person=[{id:1,name:'tom',age:23,skill:'react'},{id:2,name:'Jerry',age:24,skill:'vue'}]
const persons=person.map(p=><h2>{p.id} {p.name} {p.skill}</h2>)

  return (
    <div>{persons}</div>
  )
}

export default PersonList