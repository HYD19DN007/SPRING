import React from "react";
const Hello=()=>
{
//return

{/* <div>
<h1>
    Welcome to Jfx
</h1>

</div> */}
return React.createElement("div",null,React.createElement("H1",null,"Welcome to JFX"));

}
export default Hello;