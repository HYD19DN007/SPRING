import React from 'react'

function FunctionClick() {
function clickHander()
{
console.log("hello");

}

  return (
    <div><button onClick={clickHander}>FunctionClick</button></div>
  
    )
}

export default FunctionClick

