import React, { Component } from 'react'

 class ClickClass extends Component {
  ClickHander()
  {
console.log("Class Clicked")

  }
    render() {
    return (
      <div><button onClick={this.ClickHander}>Click</button></div>
    )
  }
}

export default ClickClass