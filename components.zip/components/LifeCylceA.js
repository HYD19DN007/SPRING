import React, { Component } from 'react'
import LifeCylceB from './LifeCycleB'

class LifeCylceA extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         name:'Gayatri'

      }
    console.log('LifeCycle A Constructor')
    }
    static getDerivedStateFromProps(props,state)
    {
        console.log('LifeCycle A static method')
        return null
    }
    componentDidMount()
    {
        console.log('LifeCycle A did mount method')
        return null
        
    }
  render() {
        console.log('LifeCycle A render')
        return (
      
      <div>LifeCylceA
      <LifeCylceB></LifeCylceB>
      </div>
    )
  }
}

export default LifeCylceA