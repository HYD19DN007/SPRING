import React from 'react'

function FragmentDemo() {
  return (
    <React.Fragment>     
        <h1>Fragment Demo</h1>
        <p> this is demo on fragment demo</p>
        </React.Fragment>

  )
}

export default FragmentDemo