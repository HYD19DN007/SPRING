import React, { Component } from 'react'

export class Eventbind extends Component {
    constructor(props)
    {
        super(props)
        this.state={
            message:'hello'
        }
        this.ClickHandler=this.ClickHandler.bind(this)
    }

    ClickHandler()
    {
        this.setState({
           message:'Good Bye'
       })
        // console.log(this)
    }
  render() {
    return (
        <div>
        <div>{this.state.message}</div>
        <div><button onClick={this.ClickHandler.bind(this)}>EventBind</button></div>
        <div><button onClick={()=>this.ClickHandler()}>EventBind</button></div>
        <div><button onClick={this.ClickHandler}>EventBind</button></div>
       
        </div>
        )
  }
}

export default Eventbind