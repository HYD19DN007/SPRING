const Employees = ({empdata}) => {
return ( 
<table>
<thead>
    <tr>
        <th>Name</th>
        <th>Date of Birth</th>

    </tr>
</thead>
<tbody>
        {
            empdata.map((item=>(
                <tr key={item.id}>
                    <td>{item.id}</td>
                    <td>{item.name}</td>
                    <td>{item.age}</td>
                </tr>
            )))
        }
</tbody>

</table>
);
}
 
export default Employees;
