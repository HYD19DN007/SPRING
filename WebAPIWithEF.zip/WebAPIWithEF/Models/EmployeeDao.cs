﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace WebAPIWithEF.Models
{
    public class EmployeeDao: IEmployeeDao
    {
        sampleEntities db = new sampleEntities();
        public List<Employee> FetchAllEmployees()
        {
            return db.Employees.ToList();
        }
        public Employee FetchById(int id)
        {
            return db.Employees.ToList().Where(e => e.Empno == id).FirstOrDefault();
        }
        public List<Employee> FetchByName(string name)
        {
            return db.Employees.ToList().Where(e => e.Ename.Equals(name)).ToList();
        }
        public List<Country> FetchCountries()
        {
            return db.Countries.ToList();
        }







        public void insertEmp(Employee E)
        {
            db.Entry(E).State = EntityState.Added;
            db.Employees.Add(E);
            db.SaveChanges();
        }
        public void updateEmp(int id, Employee newemp)
        {
            Employee emp = db.Employees.ToList().Where(e => e.Empno == id).FirstOrDefault();
            emp.Ename = newemp.Ename;
            emp.Basic = newemp.Basic;
            emp.Doj = newemp.Doj;
            db.Entry(emp).State = EntityState.Modified;
            db.SaveChanges();
        
        }
        public void deleteEmp(int id)
        {
            Employee emp = db.Employees.ToList().Where(e => e.Empno == id).FirstOrDefault();
            db.Entry(emp).State = EntityState.Deleted;
            db.SaveChanges();
        }






    }
}