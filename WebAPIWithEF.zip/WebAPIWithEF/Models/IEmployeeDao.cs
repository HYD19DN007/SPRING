﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebAPIWithEF.Models
{
    interface IEmployeeDao
    {
         List<Employee> FetchAllEmployees();
        void insertEmp(Employee E);
        void updateEmp(int id, Employee newemp);
        void deleteEmp(int id);
        Employee FetchById(int id);
        List<Employee> FetchByName(string name);
        List<Country> FetchCountries();


    }
}
