﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;
using WebAPIWithEF.Models;

namespace WebAPIWithEF.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class EmployeeController : ApiController
    {
        IEmployeeDao E = new EmployeeDao();
        [HttpGet]
        [Route("api/Employee")]
        public HttpResponseMessage getAll()
        {
            List<Employee> list = E.FetchAllEmployees();
            if (list.Count != 0)
            {
                return Request.CreateResponse(HttpStatusCode.OK, list);
            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.NotFound, "No Employee found");

            }
        }
        [HttpGet]
        [Route("api/Employee/getByName/{name}")]
        public HttpResponseMessage getByName(string name)
        {
            List<Employee> emp = E.FetchByName(name);
            if (emp.Count() != 0)
            {
                return Request.CreateResponse(HttpStatusCode.OK, emp);

            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.NotFound, "No Employee Exists");
            }

        }
        [HttpGet]
        [Route("api/Employee/getById/{id}")]
        public HttpResponseMessage getById(int id)
        {
            Employee emp = E.FetchById(id);
            if (emp != null)
            {
                return Request.CreateResponse(HttpStatusCode.OK, emp);

            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.NotFound, "No Employee Exists");
            }

        }

        [HttpPost]
        [Route("api/Employee/")]

        public HttpResponseMessage postEmp([FromBody] Employee emp)
        {
            try
            {
                E.insertEmp(emp);
                return Request.CreateResponse(HttpStatusCode.OK, "Employee Inserted");
            }
            catch (DbUpdateException E)
            {
                SqlException sql = E.GetBaseException() as SqlException;
                String msg = sql.Message;
                if (msg.Contains("PK_Employee"))
                    return Request.CreateResponse(HttpStatusCode.InternalServerError, "Empno cannot be duplicate");
                else if (msg.Contains("CK_Employee"))
                    return Request.CreateResponse(HttpStatusCode.InternalServerError, "Basic must be greater than 10000");
                else
                    return Request.CreateResponse(HttpStatusCode.InternalServerError, "Could not insert");
            }

        }
        [HttpPut]
        [Route("api/Employee/{id}")]
        public HttpResponseMessage updateEmp(int id, [FromBody] Employee emp)
        {
            Employee old = E.FetchById(id);
            try
            {
                if (old != null)
                {
                    E.updateEmp(id, emp);
                    return Request.CreateResponse(HttpStatusCode.OK, "Employee Updated");
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NotFound, "Employee does not exist");
                }
            }
            catch (DbUpdateException E)
            {
                SqlException sql = E.GetBaseException() as SqlException;
                if (sql.Message.Contains("CK_Employee"))
                    return Request.CreateResponse(HttpStatusCode.InternalServerError, "Basic should be greater than 10000");
                else if (sql.Message.Contains("CK_Doj"))
                    return Request.CreateResponse(HttpStatusCode.InternalServerError, "Doj should be greater than 2001-01-01");
                else
                    return Request.CreateResponse(HttpStatusCode.InternalServerError, "Could not update the data");
            }
        }

        [HttpDelete]
        [Route("api/Employee/{id}")]
        public HttpResponseMessage DeleteEmp(int id)
        {
            Employee old = E.FetchById(id);


            if (old != null)
            {
                E.deleteEmp(id);
                return Request.CreateResponse(HttpStatusCode.OK, "Employee deleted");
            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.NotFound, "Employee does not exist");
            }


        }
        [HttpGet]
        [Route("api/Employee/country")]
        public HttpResponseMessage getcountries()
        {
            List<Country> country = E.FetchCountries();
            if (country.Count() != 0)
            {
                return Request.CreateResponse(HttpStatusCode.OK, country);

            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.NotFound, "No countries Exists");
            }

        }

    }
}