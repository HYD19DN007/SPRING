package com.techwave.mvc.controllers;

import java.util.List;
import java.util.stream.Collectors;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.techwave.mvc.model.dao.Empdao;
import com.techwave.mvc.model.pojo.Book;
import com.techwave.mvc.model.pojo.Deptdata;
import com.techwave.mvc.model.pojo.Emp;

@Controller
public class EmpController {
	@Autowired
	Empdao empdao;
	static List<Deptdata> list=null;
	@RequestMapping("/")
	public String Extract(Model M) {
		System.out.println(empdao.Extract().size());
		M.addAttribute("Elist", empdao.Extract());
		return "Displayemp";
	}


	@RequestMapping("setdeptno")
	public String setDeptno()
	{
		return "setDeptno";
	}
	
	@RequestMapping("fetch")
	public String Extract2(@RequestParam("deptno") Integer dno, Model M)
	{
		List<Emp> list = empdao.Extract().stream().filter(i -> i.getDeptno()==dno).collect(Collectors.toList());
		M.addAttribute("Elist", list);
		return "displayDeptno";
	}

	@RequestMapping("getemps")
	public String getEmps(Model M) {
		list=empdao.extractDept();
		M.addAttribute("dlist",list);
		return "getEmp";
	}
	@RequestMapping("getEmpbyDept")
	public String getEmpbyDept(@RequestParam("dno") int dno,Model M)
	{
	 
		List<Emp> Elist=empdao.Extract().stream().filter(i->i.getDeptno()==dno).collect(Collectors.toList());
		M.addAttribute("Elist",Elist);
		M.addAttribute("dlist",list);
		M.addAttribute("dno",dno);
		return "getEmp";
	}
	
	@RequestMapping("insert")
	public String insertBook(Model M)
	{
		M.addAttribute("book",new Book());
		return "insert";
		
	}
	@RequestMapping("getBook")
	 @Transactional
	public String getBook(@ModelAttribute("book") Book B,Model M)
	{
		System.out.println(B.getBookid()+" "+B.getBookname()+" "+B.getDop());
		System.out.println("first");
		String S=empdao.insertBook(B);
		M.addAttribute("msg", S);
		System.out.println("first");
		return "insert";
		
	}
	
	@RequestMapping("updateBook")
	public String updateBook(Model M)
	{
		List<Book> blist=empdao.extractBook();
		M.addAttribute("blist", blist);
		M.addAttribute("book", new Book());
		return "Update";
	}
	
	@RequestMapping("fetchBook/{bid}")
	public String FetchBook(@PathVariable("bid") int bid, Model M)
	{
		System.out.println("testing");
		Book B=empdao.extractBook().stream().filter(i -> i.getBookid()==bid).collect(Collectors.toList()).get(0);
		M.addAttribute("book",B);
		return "Update";
	}
	
	@RequestMapping("search")
	public String search()
	{
		return "search";
		
	}
	
	@RequestMapping("searchBy")
	public String search(@RequestParam("option") String option, @RequestParam("no") int no,Model M)
	{
		List<Emp> list;
		if(option.equals("dno")) {
			list =  empdao.Extract().stream().filter(i -> i.getDeptno()==no).collect(Collectors.toList());
			M.addAttribute("list", list);
		}
		else if (option.equals("eno")) {
			list = empdao.Extract().stream().filter(i -> i.getEmpno()==no).collect(Collectors.toList());
			M.addAttribute("list", list);
		}
		return "search";
		
	}
	

}
