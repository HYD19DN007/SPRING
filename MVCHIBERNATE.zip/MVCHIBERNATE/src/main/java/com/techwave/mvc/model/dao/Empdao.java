package com.techwave.mvc.model.dao;

import java.util.List;

import org.springframework.orm.hibernate5.HibernateTemplate;

import com.techwave.mvc.model.pojo.Book;
import com.techwave.mvc.model.pojo.Deptdata;
import com.techwave.mvc.model.pojo.Emp;

public class Empdao {
	HibernateTemplate template;

	public void setTemplate(HibernateTemplate template) {
		this.template = template;
	}
	
	public List<Emp> Extract() {
		//loadall is a method of hibernate template to access the rows of a table
		return template.loadAll(Emp.class);
	}
	
	public List<Deptdata> extractDept() {
		//loadall is a method of hibernate template to access the rows of a table
		return template.loadAll(Deptdata.class);
	}
	
	public List<Book> extractBook() {
		//loadall is a method of hibernate template to access the rows of a table
		return template.loadAll(Book.class);
	}
	
	public String insertBook(Book B) {
		/* template.save(B); */
		template.save(B);
		return "Book data stored";
	}
}
