package com.techwave.mvc.model.pojo;

public class Vendor {

}
