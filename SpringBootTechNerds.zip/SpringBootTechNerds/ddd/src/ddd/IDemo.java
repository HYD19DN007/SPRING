package ddd;

public interface IDemo {

}
